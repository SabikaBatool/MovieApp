//
//  MovieViewModel.swift
//  MusicApp
//
//  Created by Sabika Batool on 13/08/2023.
//

import Foundation

final class MovieViewModel {
    weak var delegate: RequestDelegate?
    private var state: ViewState {
        didSet {
            self.delegate?.didUpdate(with: state)
        }
    }

    private var movieArray: [Movie] = []
    var filteredMovieArray: [Movie] = []
    
    var textEntered: String {
        didSet {
            self.state = .idle
            self.filterData(str: textEntered)
        }
    }
  
    init() {
        self.state = .idle
        self.textEntered = ""
    }
}

// MARK: - DataSource
extension MovieViewModel {
    var numberOfItems: Int {
        if textEntered != "" {
            return filteredMovieArray.count
        }else {
            return movieArray.count
        }
    }

    func getInfo(for index: Int) -> (id: Int, title: String, releaseDate: String, rating: Double, imageURL: String?) {
        let movie: Movie
        if textEntered != "" {
            movie = filteredMovieArray[index]
        }else {
            movie = movieArray[index]
        }
        return (id: movie.id ,title: movie.title, releaseDate: movie.release_date, rating: movie.vote_average, imageURL: movie.poster_path)
    }
}

// MARK: - Service Call
extension MovieViewModel {
    func loadData() {
        if Reachability.isConnectedToNetwork() {
            self.state = .loading
            let urlStr = ApiUrl.init().movieListUrl
          
            let urlRequest = URLRequest(url: URL(string: urlStr)!)
            let serviceManager = MovieService(request: urlRequest)
            
            serviceManager.getAllMovie { result in
                switch result {
                case let .success(musicList):
                    self.movieArray = musicList
                    self.state = .success
                case let .failure(error):
                    self.movieArray = []
                    self.state = .error(error)
                }
            }
        }
    }
}

// MARK: - Filter Data
private extension MovieViewModel {
    func filterData(str: String) {
       self.filteredMovieArray = self.movieArray.filter { $0.title.lowercased().contains(str.lowercased()) }
        self.state = .success
    }
}
