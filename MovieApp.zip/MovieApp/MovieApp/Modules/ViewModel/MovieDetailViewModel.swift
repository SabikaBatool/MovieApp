//
//  MovieDetailViewModel.swift
//  MovieApp
//
//  Created by Babar Rauf on 16/08/2023.
//

import Foundation

final class MovieDetailViewModel {
    weak var delegate: RequestDelegate?
    private var state: ViewState {
        didSet {
            self.delegate?.didUpdate(with: state)
        }
    }

    private var movieDetail: MovieDetail?
  
    init() {
        self.state = .idle
    }
    
    func getdata() -> (title: String?, releaseDate: String?, rating: Double?, imageURL: String?, budget: Int?, homepage: String?, desc: String?, movieStatus: String?, tagline: String?) {
        return (title: movieDetail?.title, releaseDate: movieDetail?.release_date, rating: movieDetail?.vote_average, imageURL: movieDetail?.backdrop_path, budget: movieDetail?.budget, homepage: movieDetail?.homepage, desc: movieDetail?.overview, movieStatus: movieDetail?.status, tagline: movieDetail?.tagline)
    }
}
//title --
//backdrop_path --
//budget --
//homepage
//overview --
//release_date --
//status
//tagline
//vote_average --

// MARK: - Service Call
extension MovieDetailViewModel {
    func populateData(id: Int) {
        if Reachability.isConnectedToNetwork() {
            self.state = .loading
            let urlStr = "\(ApiUrl.init().baseUrlForDetails)\(String(describing: id))\("?language=en-US")"
            
            let urlRequest = URLRequest(url: URL(string: urlStr)!)
            let serviceManager = MovieService(request: urlRequest)
            
            serviceManager.getMovieDetails { result in
                switch result {
                case let .success(movieDetails):
                    self.movieDetail = movieDetails
                    self.state = .success
                case let .failure(error):
                    self.movieDetail = nil
                    self.state = .error(error)
                }
            }
        }
    }
}

