//
//  MovieDetailViewController.swift
//  MovieApp
//
//  Created by Babar Rauf on 16/08/2023.
//

import UIKit

class MovieDetailViewController: UIViewController {
    
    @IBOutlet weak var movieTitleLbl: UILabel!
    @IBOutlet weak var movieTaglineLbl: UILabel!
    @IBOutlet weak var posterImageView: UIImageView!
    @IBOutlet weak var descLbl: UILabel!
    @IBOutlet weak var releaseDateLbl: UILabel!
    @IBOutlet weak var budgetLbl: UILabel!
    @IBOutlet weak var ratingLbl: UILabel!
    @IBOutlet weak var statusLbl: UILabel!
    @IBOutlet weak var websiteLbl: UILabel!
    
    var selectedMovieId: Int

    private var viewModel = MovieDetailViewModel()

    init?(coder: NSCoder, selectedMovieId: Int) {
        self.selectedMovieId = selectedMovieId
        super.init(coder: coder)
    }

    required init?(coder: NSCoder) {
        fatalError("You must create this view controller with a movie id.")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewModel.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.populateData(id: selectedMovieId)
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        ActivityIndicator.sharedIndicator.hideActivityIndicator()
    }
    
    
    func showData() {
        let movieData = viewModel.getdata()
        movieTitleLbl.text = movieData.title
        movieTaglineLbl.text = movieData.tagline
        
        let imageURL = URL(string: "\(ApiUrl.init().imgBaseUrl)\(String(describing: movieData.imageURL!))")
        
        posterImageView?.kf.setImage(with: imageURL!, placeholder: #imageLiteral(resourceName: "moviePlaceholder"))
        posterImageView.image = posterImageView.image?.compressImage(image: posterImageView.image!, size: 200)
        
        descLbl.text = movieData.desc
        releaseDateLbl.text = movieData.releaseDate
        budgetLbl.text = String(format: "%d", movieData.budget!)
        ratingLbl.text = String(format: "%.1f", movieData.rating!)
        statusLbl.text = movieData.movieStatus
        websiteLbl.text = movieData.homepage
    }
}

// MARK: RequestDelegate
extension MovieDetailViewController: RequestDelegate {
    func didUpdate(with state: ViewState) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            switch state {
            case .idle:
                break
            case .loading:
                ActivityIndicator.sharedIndicator.displayActivityIndicator(onView: view)
            case .success:
                self.showData()
                ActivityIndicator.sharedIndicator.hideActivityIndicator()
            case .error(let error):
                ActivityIndicator.sharedIndicator.hideActivityIndicator()
                self.present(error: error, customAction: UIAlertAction(title: "Try Again", style: .default, handler: { [weak self] _ in
                    guard let self = self else { return }
                    self.viewModel.populateData(id: selectedMovieId)
                }))
            }
        }
    }
    
    
}

