//
//  MovieViewController.swift
//  MovieApp
//
//  Created by Babar Rauf on 16/08/2023.
//

import UIKit

class MovieViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var movieTableView: UITableView!
    
    private var viewModel = MovieViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewModel.delegate = self
        setupView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.loadData()
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        ActivityIndicator.sharedIndicator.hideActivityIndicator()
    }
    
    // MARK: Setup UI
    func setupView() {
        movieTableView.delegate = self
        movieTableView.dataSource = self
        
        let cellNib = UINib(nibName: MovieTableViewCell.reuseIdentifier, bundle: nil)
        movieTableView.register(cellNib, forCellReuseIdentifier: MovieTableViewCell.reuseIdentifier)
       
        movieTableView.rowHeight = UITableView.automaticDimension
        movieTableView.estimatedRowHeight = 85
    }
    
    func navigateToDetails(movieId: Int) {
        guard let vc = storyboard?.instantiateViewController(identifier: "MovieDetailViewController", creator: { coder in
            return MovieDetailViewController(coder: coder, selectedMovieId: movieId)
            }) else {
                fatalError("Failed to load EditUserViewController from storyboard.")
            }
            navigationController?.pushViewController(vc, animated: true)
    }

}

// MARK: UITableViewDataSource & UITableViewDelegate
extension MovieViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfItems
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieTableViewCell.reuseIdentifier, for: indexPath) as! MovieTableViewCell
            cell.configure(info: viewModel.getInfo(for: indexPath.row))
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        navigateToDetails(movieId: viewModel.getInfo(for: indexPath.row).id)
    }
}

// MARK: - UITextFieldDelegate

extension MovieViewController : UITextFieldDelegate {
    
    func textField(_ textField: UITextField,
                   shouldChangeCharactersIn range: NSRange,
                   replacementString string: String) -> Bool{
        
        guard let oldTextString = textField.text else {
            return true
        }
        
        let oldText = oldTextString as NSString
        let newString = oldText.replacingCharacters(in: range, with: string) as NSString
        viewModel.textEntered = newString as String
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
            textField.resignFirstResponder()
            return true
        }
}

// MARK: RequestDelegate
extension MovieViewController: RequestDelegate {
    func didUpdate(with state: ViewState) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            switch state {
            case .idle:
                break
            case .loading:
                ActivityIndicator.sharedIndicator.displayActivityIndicator(onView: view)
            case .success:
                self.movieTableView.setContentOffset(.zero, animated: true)
                self.movieTableView.reloadData()
                ActivityIndicator.sharedIndicator.hideActivityIndicator()
            case .error(let error):
                ActivityIndicator.sharedIndicator.hideActivityIndicator()
                self.present(error: error, customAction: UIAlertAction(title: "Try Again", style: .default, handler: { [weak self] _ in
                    guard let self = self else { return }
                    self.viewModel.loadData()
                }))
            }
        }
    }
    
    
}

extension UIViewController {
    func present(error: Error, customAction: UIAlertAction? = nil, handler: ((UIAlertAction) -> Void)? = nil) {
        DispatchQueue.main.async {
            self.present(title: "Oops", message: error.localizedDescription)
        }
    }
    
    func present(title: String, message: String, customAction: UIAlertAction? = nil, handler: ((UIAlertAction) -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: handler))
        if let customAction = customAction {
            alert.addAction(customAction)
        }
        present(alert, animated: true)
    }
}

