//
//  MovieTableViewCell.swift
//  MovieApp
//
//  Created by Babar Rauf on 16/08/2023.
//

import UIKit
import Kingfisher

class MovieTableViewCell: UITableViewCell {

    static let reuseIdentifier = "\(MovieTableViewCell.self)"

    @IBOutlet weak var movieImageView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var releaseDateLbl: UILabel!
    @IBOutlet weak var ratingLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.movieImageView?.image = nil
        self.titleLbl?.text = nil
        self.releaseDateLbl?.text = nil
        self.ratingLbl?.text = nil
    }

}

// MARK: - Configuration
extension MovieTableViewCell {
    func configure(info: (id: Int, title: String, releaseDate: String, rating: Double, imageURL: String?)) {
        self.titleLbl?.text = info.title
        self.releaseDateLbl?.text = info.releaseDate
        self.ratingLbl?.text = String(info.rating)
        guard let urlString = info.imageURL,
        let imageURL = URL(string: "\(ApiUrl.init().imgBaseUrl)\(urlString)") else { return }
        
        self.movieImageView?.kf.setImage(with: imageURL, placeholder: #imageLiteral(resourceName: "moviePlaceholder"))
        self.movieImageView.image = self.movieImageView.image?.compressImage(image: self.movieImageView.image!, size: 60)
        
    }
    
    
}
