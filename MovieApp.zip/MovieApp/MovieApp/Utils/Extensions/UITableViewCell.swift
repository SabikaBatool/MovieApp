//
//  UITableViewCell.swift
//  MusicApp
//
//  Created by Sabika Batool on 13/08/2023.
//


import UIKit

public extension UITableViewCell {
    
    /** Return identifier with the same name of the subclass */
    static var defaultIdentifier: String {
        return String(describing: self)
    }
}
