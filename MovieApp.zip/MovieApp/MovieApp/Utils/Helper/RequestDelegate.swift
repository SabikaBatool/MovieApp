//
//  RequestDelegate.swift
//  MusicApp
//
//  Created by Sabika Batool on 13/08/2023.
//


import Foundation

protocol RequestDelegate: AnyObject {
    func didUpdate(with state: ViewState)
}
