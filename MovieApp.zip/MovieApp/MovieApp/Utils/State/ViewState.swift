//
//  ViewState.swift
//  MusicApp
//
//  Created by Sabika Batool on 13/08/2023.
//

import Foundation

enum ViewState {
    case idle
    case loading
    case success
    case error(Error)
}
