//
//  MovieService.swift
//  MusicApp
//
//  Created by Sabika Batool on 12/08/2023.
//

import Foundation
import UIKit

struct ApiUrl {
    private var baseURL: String {
        return "https://api.themoviedb.org/3/movie/"
    }
    
    private var apiKey: String {
        return "0e83b3076f4e549a1d6e84897ae01ae6"
    }
    
    var imgBaseUrl: String {
        return "https://image.tmdb.org/t/p/w200"
    }

    var movieListUrl: String {
        return "\(baseURL)\("popular?")\("language=en-US&page=1")"
    }
    
    var baseUrlForDetails: String {
        return "https://api.themoviedb.org/3/movie/"
    }
    
    private enum Endpoint {
        case movieList
        case apiKeyStr
        case langStr

        var path: String {
            switch self {
            case .movieList: return "popular?"
            case .apiKeyStr: return "api_key="
            case .langStr: return "?language=en-US'"
            }
        }
    }

}

class MovieService: NSObject {
    
    private var request: URLRequest
    
    init(request: URLRequest) {
        self.request = request
    }
    
    func getAllMovie(completion: @escaping (Result<[Movie], Error>) -> Void) {

        request.httpMethod = "GET"
        let authData = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwZTgzYjMwNzZmNGU1NDlhMWQ2ZTg0ODk3YWUwMWFlNiIsInN1YiI6IjY0Y2EwNDI2YmYwOWQxMDBhZTRkNDAwNCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.CL2s7kM-vxEqeueuGpzdh1fJYz-y0Aue-t7PJlFfNu4"
        request.addValue("application/json", forHTTPHeaderField: "accept")
        request.addValue("Bearer \(authData)", forHTTPHeaderField: "Authorization")

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                print(#function, "🧨 Request: \(self.request)\nError: \(error)")
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(CustomError.noData))
                return
            }

            do {
                let movie = try JSONDecoder().decode(MovieResponse.self, from: data)
                print(#function, "🧨 Request: \(self.request)\nSuccess:")
                completion(.success(movie.results))
            } catch let error {
                print(#function, "🧨 Request: \(self.request)\nError: \(error)")
                completion(.failure(error))
            }

        }.resume()

    }
    
    func getMovieDetails(completion: @escaping (Result<MovieDetail, Error>) -> Void) {
    
        request.httpMethod = "GET"
        let authData = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIwZTgzYjMwNzZmNGU1NDlhMWQ2ZTg0ODk3YWUwMWFlNiIsInN1YiI6IjY0Y2EwNDI2YmYwOWQxMDBhZTRkNDAwNCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.CL2s7kM-vxEqeueuGpzdh1fJYz-y0Aue-t7PJlFfNu4"
        request.addValue("application/json", forHTTPHeaderField: "accept")
        request.addValue("Bearer \(authData)", forHTTPHeaderField: "Authorization")

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                print(#function, "🧨 Request: \(self.request)\nError: \(error)")
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(CustomError.noData))
                return
            }

            do {
                let movie = try JSONDecoder().decode(MovieDetail.self, from: data)
                print(#function, "🧨 Request: \(self.request)\nSuccess:")
                completion(.success(movie))
            } catch let error {
                print(#function, "🧨 Request: \(self.request)\nError: \(error)")
                completion(.failure(error))
            }

        }.resume()

    }
}
