//
//  MusicService.swift
//  MusicApp
//
//  Created by Babar Rauf on 12/08/2023.
//

import Foundation

struct ApiUrl {
    private var baseURL: String {
        return "https://itunes.apple.com"
    }
    
    private var path: String {
        return "/search?term=all&entity=song"
    }

    var url: String {
        return "\(baseURL)\(path)"
    }

}

final class MusicService {

//https://itunes.apple.com/search?term=all&entity=song


    static func getAllMusic(completion: @escaping (Result<[Music], Error>) -> Void) {
        guard Reachability.isConnectedToNetwork(),
              let url = URL(string: ApiUrl.init().url) else {
                  completion(.failure(CustomError.noConnection))
                  return
              }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        URLSession.shared.dataTask(with: request) { data, _, error in
            if let error = error {
                print(#function, "🧨 Request: \(request)\nError: \(error)")
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(CustomError.noData))
                return
            }

            do {
                let music = try JSONDecoder().decode(MusicResponse.self, from: data)
                print(#function, "🧨 Request: \(request)\nSuccess:")
                completion(.success(music.results))
            } catch let error {
                print(#function, "🧨 Request: \(request)\nError: \(error)")
                completion(.failure(error))
            }

        }.resume()

    }
}
