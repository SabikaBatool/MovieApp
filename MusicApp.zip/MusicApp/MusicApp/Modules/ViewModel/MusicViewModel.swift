//
//  MusicViewModel.swift
//  MusicApp
//
//  Created by Babar Rauf on 13/08/2023.
//

import Foundation

final class MusicViewModel {
    weak var delegate: RequestDelegate?
    private var state: ViewState {
        didSet {
            self.delegate?.didUpdate(with: state)
        }
    }

    private var musicArray: [Music] = []
  //  private var filteredCards: [Card] = []
//    private var selectedType: Types = .all {
//        didSet {
//            self.filterData()
//        }
//    }

    init() {
        self.state = .idle
    }
}

// MARK: - DataSource
extension MusicViewModel {
    var numberOfItems: Int {
        musicArray.count
    }

    func getInfo(for indexPath: IndexPath) -> (name: String, artist: String, album: String, imageURL: String) {
        let music = musicArray[indexPath.row]
        return (name: music.trackName, artist: music.artistName, album: music.collectionName, imageURL: music.artworkUrl60)
    }
}

// MARK: - Service Call
extension MusicViewModel {
    func loadData() {
        self.state = .loading
        MusicService.getAllMusic { result in
            switch result {
            case let .success(musicList):
                self.musicArray = musicList
             //   self.filteredCards = cards
                self.state = .success
            case let .failure(error):
                self.musicArray = []
               // self.filteredCards = []
                self.state = .error(error)
            }
        }
    }
}

// MARK: - Filter Data
private extension MusicViewModel {
    func filterData() {
//        guard selectedType != .all else {
//            self.filteredCards = cards
//            self.state = .success
//            return
//        }
//
//        guard selectedType != .monsters else {
//            self.filteredCards = self.cards.filter { !$0.type.lowercased().contains(Types.spell.name.lowercased()) && !$0.type.lowercased().contains(Types.trap.name.lowercased()) }
//            self.state = .success
//            return
//        }
//
//        self.filteredCards = self.cards.filter { $0.type.lowercased().contains(self.selectedType.name.lowercased()) }
//        self.state = .success
    }
}
