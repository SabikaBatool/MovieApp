//
//  MusicViewController.swift
//  MusicApp
//
//  Created by Babar Rauf on 14/08/2023.
//

import UIKit

class MusicViewController: UIViewController {
    
    
    @IBOutlet weak var musicTableView: UITableView!
    
    private var viewModel = MusicViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // self.viewModel = viewModel
        self.viewModel.delegate = self
        setupView()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.loadData()
    }
    
    // MARK: Setup UI
    func setupView() {
        musicTableView.delegate = self
        musicTableView.dataSource = self
        musicTableView.registerCell(cellClass: MusicCell.self)
     //   musicTableView.reloadData()
       // musicTableView.rowHeight = UITableView.automaticDimension
       // musicTableView.estimatedRowHeight = 100
    }
}

// MARK: UITableViewDataSource & UITableViewDelegate
extension MusicViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.numberOfItems
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MusicCell.reuseIdentifier, for: indexPath) as! MusicCell
       // cell.selectionStyle = .none
        cell.configure(info: viewModel.getInfo(for: indexPath))
        return cell
        
        
        
//        var cell: MusicCell! = tableView.dequeueReusableCell(withIdentifier: "MusicCell") as? MusicCell
//
//            if cell == nil {
//                musicTableView.register(UINib(nibName: "MusicCell", bundle: nil), forCellReuseIdentifier: "MusicCell")
//                cell = musicTableView.dequeueReusableCell(withIdentifier: "MusicCell") as? MusicCell
//                cell.configure(info: viewModel.getInfo(for: indexPath))
//                    }
//            return cell
    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//       return UITableView.automaticDimension
//    }
}

// MARK: RequestDelegate
extension MusicViewController: RequestDelegate {
    func didUpdate(with state: ViewState) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            switch state {
            case .idle:
                break
            case .loading:
                ActivityIndicator.sharedIndicator.displayActivityIndicator(onView: view)
               // self.displayActivityIndicator(onView: self.view)
              //  self.startLoading()
            case .success:
                //self.musicTableView.setContentOffset(.zero, animated: true)
                self.musicTableView.reloadData()
                ActivityIndicator.sharedIndicator.hideActivityIndicator()
               // self.hideActivityIndicator()
              //  self.stopLoading()
            case .error(let error):
                //self.stopLoading()
               // self.hideActivityIndicator()
                ActivityIndicator.sharedIndicator.hideActivityIndicator()
                self.present(error: error, customAction: UIAlertAction(title: "Try Again", style: .default, handler: { [weak self] _ in
                    guard let self = self else { return }
                    self.viewModel.loadData()
                }))
            }
        }
    }
    
    
}

extension MusicViewController {
    func present(error: Error, customAction: UIAlertAction? = nil, handler: ((UIAlertAction) -> Void)? = nil) {
        DispatchQueue.main.async {
            self.present(title: "Oops", message: error.localizedDescription)
        }
    }
    
    func present(title: String, message: String, customAction: UIAlertAction? = nil, handler: ((UIAlertAction) -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: handler))
        if let customAction = customAction {
            alert.addAction(customAction)
        }
        
        present(alert, animated: true)
    }
}
