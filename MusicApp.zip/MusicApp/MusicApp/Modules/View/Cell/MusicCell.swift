//
//  MusicCell.swift
//  MusicApp
//
//  Created by Babar Rauf on 13/08/2023.
//

import UIKit
import Kingfisher

class MusicCell: UITableViewCell {

    @IBOutlet weak var songImageView: UIImageView?
    @IBOutlet weak var songNameLbl: UILabel?
    @IBOutlet weak var artistNameLbl: UILabel?
    @IBOutlet weak var albumNameLbl: UILabel?
    @IBOutlet weak var soundImageView: UIImageView?
    
    // MARK: - Initialization
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
       // self.backgroundColor = .white
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public class var reuseIdentifier: String {
        return "\(self.self)"
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        self.songImageView?.image = nil
        self.songNameLbl?.text = nil
        self.artistNameLbl?.text = nil
        self.albumNameLbl?.text = nil
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }

    
}

// MARK: - Configuration
extension MusicCell {
    func configure(info: (name: String, artist: String, album: String, imageURL: String?)) {
        self.songNameLbl?.text = info.name
        self.artistNameLbl?.text = info.artist
        self.albumNameLbl?.text = info.album
        guard let urlString = info.imageURL,
        let imageURL = URL(string: urlString) else { return }
        
        self.songImageView?.kf.setImage(with: imageURL, placeholder: #imageLiteral(resourceName: "placeholder"))
    }
}
